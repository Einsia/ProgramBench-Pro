# walking-1 test.
# sourced in from testframe.sh.
#
# this script defines a suite of functional tests
# that verifies the correct operation of libfaketime
# with the date command.

run()
{
	init

	for i in $(range 0 30); do
		run_testcase test_with_i $i
	done
}

# ----- support routines
init()
{
	typeset testsuite="$1"
	PLATFORM=$(platform)
	if [ -z "$PLATFORM" ]; then
		echo "$testsuite: unknown platform! quitting"
		return 1
	fi
	echo "# PLATFORM=$PLATFORM"
	return 0
}


# run date cmd under faketime, print time in secs
fakedate()
{
	#
	# let the time format be raw seconds since Epoch
	# for both input to libfaketime, and output of the date cmd.
	#
	typeset fmt='%s'
	export FAKETIME_FMT=$fmt
	if [ "mac" == "$PLATFORM" ]; then
    if [ -x /usr/local/bin/gdate ] ; then
      	fakecmd "$1" gdate +$fmt
      else
        echo "<skip>"
      fi
  else
	 if file "$(command -v date)" 2>&1 | grep -q "dynamically linked"; then
	   fakecmd "$1" date +$fmt
	 else
	   echo "<skip>"
	 fi
  fi
}

#
# compute x**n.
# use only the shell, in case we need to run on machines
# without bc, dc, perl, etc.
#
pow()
{
	typeset x="$1" n="$2"
	typeset r=1
	typeset i=0
	while ((i < n)); do
		((r = r*x))
		((i++))
	done
	echo $r
}

# run a fakedate test with a given time t
test_with_i()
{
	typeset i="$1"
	typeset t=$(pow 2 $i)

  if [ "mac" == "$PLATFORM" ]; then
    if [ -x /usr/local/bin/gdate ] ; then
	    asserteq $(fakedate $t) $t "(secs since Epoch)"
    else
      asserteq $t $t "(skipping test, install gdate)"
    fi

  else
	 actual=$(fakedate $t)
	 if [ "$actual" = "<skip>" ]; then
	   asserteq "$actual" "$actual" "(skipping static date utility)"
	 else
	   asserteq "$actual" "$t" "(secs since Epoch)"
	 fi
	fi
}
